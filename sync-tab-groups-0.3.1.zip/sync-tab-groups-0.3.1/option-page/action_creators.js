const ActionCreators = {
  setOptions: function(options) {
    return {
      type: "OPTIONS_RECEIVE",
      options: options
    };
  }
};
